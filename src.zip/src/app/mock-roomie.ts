import { Meetroomie } from './meetroomie';

export const ROOMIES: Meetroomie[] = [
  { id: 1, name: 'Phil Shotwell', detail: 'He shots well, obviously he owns a gun so becareful!' },
  { id: 2, name: 'Narco Juju', detail: 'Mr. Juju, married to Budumama Juju. You will get a two roommates!' },
  { id: 3, name: 'Budumama Juju', detail: 'Ms.Juju, married to Narco Juju. You will get a two roommates!' },
  { id: 4, name: 'Celin Dion', detail: 'Titanic, I would love to be her roommate' },
  { id: 5, name: 'Magneta Ho', detail: 'Not a Hoe, becareful pronouncing her name' },
  { id: 6, name: 'Rubber Man', detail: 'He is a rubber man' },
  { id: 7, name: 'Dyna Ma', detail: 'He is a Ma but also a man' },
  { id: 8, name: 'Dr IQ', detail: 'She got some low IQ, if you live with you will have some hard time'},
  { id: 9, name: 'Mag Mug', detail: 'Mr. Mug got his own Mug' },
  { id: 10, name: 'Tornado Baldy', detail: 'He got a tornado nado nado baldy baldy Baldy' }
];
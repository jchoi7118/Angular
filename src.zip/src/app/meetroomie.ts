export interface Meetroomie {
    id: number;
    name: string;
    detail: string;
  }
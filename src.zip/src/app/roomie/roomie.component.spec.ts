import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomieComponent } from './roomie.component';

describe('RoomieComponent', () => {
  let component: RoomieComponent;
  let fixture: ComponentFixture<RoomieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoomieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoomieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

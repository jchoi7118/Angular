import { Component, OnInit } from '@angular/core';
import { Meetroomie } from '../meetroomie';
import { ROOMIES } from '../mock-roomie';


@Component({
  selector: 'app-roomie',
  templateUrl: './roomie.component.html',
  styleUrls: ['./roomie.component.css']
})

export class RoomieComponent implements OnInit {

  roomie = ROOMIES;
  selectedRoomie: Meetroomie;

  constructor() { }

  ngOnInit() {
  }

  onSelect(roomie: Meetroomie): void {
    this.selectedRoomie= roomie;
  }
}